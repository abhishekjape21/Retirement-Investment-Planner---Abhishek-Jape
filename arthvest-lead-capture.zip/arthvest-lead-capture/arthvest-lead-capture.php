<?php
/**
 * Plugin Name: Arthvest Report Lead Capture
 * Description: Sends report-request contact details to Arthvest Support through a rate-limited REST endpoint.
 * Version: 1.0.0
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_head', function () {
    if (is_admin()) {
        return;
    }
    $config = array('endpoint' => esc_url_raw(rest_url('arthvest/v1/report-lead')));
    echo '<script>window.ArthvestLeadCapture=' . wp_json_encode($config) . ';</script>' . "\n";
}, 1);

add_action('rest_api_init', function () {
    register_rest_route('arthvest/v1', '/report-lead', array(
        'methods' => 'POST',
        'callback' => 'arthvest_report_lead_capture',
        'permission_callback' => '__return_true',
    ));
});

add_shortcode('arthvest_calculator', function () {
    $frame_id = wp_unique_id('arthvest-calculator-');
    $src = plugins_url('wordpress-calculator.html', __FILE__);
    return '<iframe id="' . esc_attr($frame_id) . '" title="Arthvest Financial Calculator" src="' . esc_url($src) . '" loading="lazy" style="display:block;width:100%;height:1200px;min-height:900px;border:0" referrerpolicy="same-origin"></iframe>'
        . '<script>(function(){var f=document.getElementById(' . wp_json_encode($frame_id) . ');if(!f)return;window.addEventListener("message",function(e){if(e.origin!==window.location.origin||e.source!==f.contentWindow||!e.data||e.data.type!=="arthvest-calculator-height")return;var h=Number(e.data.height);if(Number.isFinite(h)&&h>0)f.style.height=Math.max(900,Math.ceil(h))+"px"})})();</script>';
});

function arthvest_report_lead_capture(WP_REST_Request $request) {
    $origin = $request->get_header('origin');
    $site_host = strtolower((string) wp_parse_url(home_url('/'), PHP_URL_HOST));
    $origin_host = strtolower((string) wp_parse_url($origin, PHP_URL_HOST));

    // This public form is intended for the calculator running on this WordPress site only.
    if (!$origin_host || !$site_host || !hash_equals($site_host, $origin_host)) {
        return new WP_Error('arthvest_invalid_origin', 'This report form can only be submitted from the Arthvest website.', array('status' => 403));
    }

    $data = $request->get_json_params();
    if (!is_array($data)) {
        return new WP_Error('arthvest_invalid_request', 'The request could not be read. Please try again.', array('status' => 400));
    }

    // Quietly accept bot honeypot submissions without sending or revealing validation details.
    if (!empty($data['website'])) {
        return rest_ensure_response(array('success' => true));
    }

    $ip = (string) $request->get_header('x-forwarded-for');
    if ($ip !== '') {
        $ip = trim(explode(',', $ip)[0]);
    } else {
        $ip = (string) $request->get_header('x-real-ip');
    }
    if ($ip === '') {
        $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : 'unknown';
    }
    $rate_key = 'arthvest_lead_' . hash('sha256', wp_salt('auth') . '|' . $ip);
    $attempts = (int) get_transient($rate_key);
    if ($attempts >= 5) {
        return new WP_Error('arthvest_rate_limited', 'Too many report requests were submitted. Please try again later.', array('status' => 429));
    }
    set_transient($rate_key, $attempts + 1, 15 * MINUTE_IN_SECONDS);

    $first_name = isset($data['firstName']) ? sanitize_text_field($data['firstName']) : '';
    $last_name = isset($data['lastName']) ? sanitize_text_field($data['lastName']) : '';
    $email = isset($data['email']) ? sanitize_email($data['email']) : '';
    $phone = isset($data['phone']) ? sanitize_text_field($data['phone']) : '';
    $digits = preg_replace('/\D+/', '', $phone);

    if (strlen($first_name) < 1 || strlen($first_name) > 80 || strlen($last_name) < 1 || strlen($last_name) > 80) {
        return new WP_Error('arthvest_invalid_name', 'Enter a valid first and last name.', array('status' => 400));
    }
    if (!is_email($email) || strlen($email) > 254) {
        return new WP_Error('arthvest_invalid_email', 'Enter a valid email address.', array('status' => 400));
    }
    if (strlen($phone) > 30 || strlen($digits) < 7 || strlen($digits) > 15) {
        return new WP_Error('arthvest_invalid_phone', 'Enter a valid contact number.', array('status' => 400));
    }
    $name = $first_name . ' ' . $last_name;
    $subject = 'New calculator report request';
    $message = "A customer requested a financial calculator report.\n\n"
        . 'Name: ' . $name . "\n"
        . 'Email: ' . $email . "\n"
        . 'Phone: ' . $phone . "\n"
        . 'Received: ' . current_time('mysql') . "\n";
    $headers = array('Reply-To: ' . $name . ' <' . $email . '>');

    if (!wp_mail('arthvestsupport@gmail.com', $subject, $message, $headers)) {
        return new WP_Error('arthvest_email_failed', 'We could not send your details right now. Please try again later.', array('status' => 503));
    }

    return rest_ensure_response(array('success' => true));
}
